KKU Affiliated Dorm Media Pack
รวมรูปภาพและลิงก์วิดีโอสำหรับใช้ประกอบการออกแบบ UI เว็บระบบรับสมัครและจองหอพักในกำกับ มข.

โครงสร้างไฟล์หลัก
- nopparat_9_buildings/ : รูปหอพักนพรัตน์ / หอ 9 หลัง
- wora_residence_8_buildings/ : รูปหอพักวรเรสซิเดนซ์ / หอ 8 หลัง
- wora_international/ : รูปหอพักวรอินเตอร์ / หออินเตอร์
- videos/video_sources.csv : รายการลิงก์วิดีโอที่ค้นเจอ
- videos/video_index.html : เปิดดูเป็นหน้าเว็บรวมลิงก์วิดีโอ
- videos/link_shortcuts/ : ไฟล์ .url สำหรับเปิดวิดีโอเร็วบน Windows
- source_manifest.csv : แหล่งที่มาของรูปภาพ
- contact_sheet_preview.jpg : ภาพรวม preview ของรูปทั้งหมด

คำแนะนำ
- ใช้รูปเพื่อ mockup / senior project presentation ได้
- ถ้าจะเผยแพร่บนเว็บจริง ให้ขออนุญาตเจ้าของภาพหรือหน่วยงานต้นทางก่อน
- วิดีโอไม่ได้ถูกดาวน์โหลดเป็น MP4 เพื่อหลีกเลี่ยงปัญหาลิขสิทธิ์และเงื่อนไขแพลตฟอร์ม
